﻿
namespace NpsiJudgingApp
{
  public static class Constants
  {
    // can't be nested to bind from Xaml markup
    public static int PenaltyStatus_Approved { get => PenaltyStatus.APPROVED; }
    public static int PenaltyStatus_Denied { get => PenaltyStatus.DENIED; }
    public static int PenaltyStatus_Pending { get => PenaltyStatus.PENDING; }

    public struct EventStatus
    {
      public const string ACTIVE = "Started";
      public const string STARTED = "Opened";
      public const string COMPLETED = "Completed";
    }

    public struct Role
    {
      public const string JUDGE = "Judge";
      public const string LEAD = "Lead Judge";
      public const string ADMIN = "Event - Admin";
    }

    public struct PenaltyStatus
    {
      public const int APPROVED = 1;
      public const int PENDING = 0;
      public const int DENIED = -1;
    }
  }
}
