﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace NpsiJudgingApp
{
  public class AppSettingsManager
  {
    private static AppSettingsManager _instance;
    private JObject _secrets;

    private const string _namespace = "NpsiJudgingApp";
    private const string _fileName = "appsettings.json";

    private AppSettingsManager()
    {
      try
      {
        var assembly = IntrospectionExtensions.GetTypeInfo(typeof(AppSettingsManager)).Assembly;
        var stream = assembly.GetManifestResourceStream(string.Format("{0}.{1}", _namespace, _fileName));
        using (var reader = new StreamReader(stream))
        {
          var json = reader.ReadToEnd();
          _secrets = JObject.Parse(json);
        }
      }
      catch (Exception ex)
      {
        Debug.WriteLine("Unable to load secrets file");
      }
    }

    public static AppSettingsManager AppSettings
    {
      get
      {
        if (_instance == null)
        {
          _instance = new AppSettingsManager();
        }

        return _instance;
      }
    }

    public string this[string name]
    {
      get
      {
        try
        {
          var path = name.Split(':');

          JToken node = _secrets[path[0]];
          for (int index = 1; index < path.Length; index++)
          {
            node = node[path[index]];
          }

          return node.ToString();
        }
        catch (Exception)
        {
          Debug.WriteLine(string.Format("Unable to retrieve secret '{0}'", name));
          return string.Empty;
        }
      }
    }
  }
}
