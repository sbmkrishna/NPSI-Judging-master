﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NpsiJudgingApp.Views
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class EventMenu : ContentPage
  {
    public EventMenu()
    {
      InitializeComponent();
    }
  }
}