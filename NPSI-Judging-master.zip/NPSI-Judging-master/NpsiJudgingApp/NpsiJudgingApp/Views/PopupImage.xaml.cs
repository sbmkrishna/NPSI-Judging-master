﻿using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NpsiJudgingApp.Views
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class PopupImage : PopupPage
  {
    private byte[] m_iba;
    public byte[] ImageByteArray
    {
      get => m_iba;
      set
      {
        m_iba = value;
      }
    }

    public PopupImage(byte[] MyImage)
    {
      this.ImageByteArray = MyImage;
      InitializeComponent();

      var stream1 = new System.IO.MemoryStream(this.ImageByteArray);
      ImageData.Source = ImageSource.FromStream(() => stream1);
    }

    public async void OnClose(object sender, EventArgs args)
    {
      await PopupNavigation.Instance.PopAsync();
    }
  }
}