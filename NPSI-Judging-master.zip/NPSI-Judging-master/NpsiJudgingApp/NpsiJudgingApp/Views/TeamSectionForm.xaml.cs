﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NpsiJudgingApp.Views
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class TeamSectionForm : ContentPage
  {
    public delegate void ScoresUpdated(string info);
    public event ScoresUpdated ScoresUpdatedEvent;

    protected override void OnDisappearing()
    {
      base.OnDisappearing();
      ScoresUpdatedEvent?.Invoke("testing");
    }

    public TeamSectionForm()
    {
      InitializeComponent();
    }

    private void Entry_TextChanged(object sender, TextChangedEventArgs e)
    {
      if (!string.IsNullOrWhiteSpace(e.NewTextValue))
      {
        bool isValid = e.NewTextValue.ToCharArray().All(x => char.IsDigit(x) || x == '.'); //Make sure all characters are numbers
        ((Entry)sender).Text = isValid ? e.NewTextValue : e.NewTextValue.Remove(e.NewTextValue.Length - 1);
      }
    }

    private async void CameraButton_Clicked(object sender, EventArgs e)
    {
      var btn = (Button)sender;
      Image photoImage = (Image)btn.Parent.FindByName("PhotoImage");
      
      //Application.Current.MainPage.DisplayAlert("Button", btn.Parent.FindByName("PhotoImage").ToString(), "Ok");

      var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions() { });
      
      if (photo != null) photoImage.Source = ImageSource.FromStream(() => { return photo.GetStream(); });
    }
  }
}