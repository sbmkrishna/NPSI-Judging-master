﻿using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NpsiJudgingApp.Views
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class PopupHtmlLabel : PopupPage
  {
    private string m_description;
    public string HtmlText
    {
      get 
      {
        return string.Format("<div style='font-size:16px; font-family:Tahoma'>{0}</div>", m_description);
      }
      set 
      {
        m_description = value;
      }
    }

    private string m_header;
    public string Header
    {
      get => m_header;
      set { m_header = value; }
    }

    public PopupHtmlLabel(string HeaderText, string HtmlText)
    {
      this.Header = HeaderText;
      this.HtmlText = HtmlText;
      InitializeComponent();
      txtHeader.Text = this.Header;
      txtHtml.Text = this.HtmlText;
    }

    public async void OnClose(object sender, EventArgs args)
    {
      await PopupNavigation.Instance.PopAsync();
    }
  }
}