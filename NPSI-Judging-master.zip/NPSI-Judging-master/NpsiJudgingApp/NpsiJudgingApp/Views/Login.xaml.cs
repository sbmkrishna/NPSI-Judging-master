﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NpsiJudgingApp.Views
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class Login : ContentPage
  {
    public Login()
    {
      InitializeComponent();
      //((ViewModels.LoginVM)BindingContext).Username = "tlaw";
      ((ViewModels.LoginVM)BindingContext).Password = "Npsi1234";
    }

  }
}