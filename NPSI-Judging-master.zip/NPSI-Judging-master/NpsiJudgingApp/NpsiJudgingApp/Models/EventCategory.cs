﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class EventCategory
  {
    public int EventID { get; set; }
    public string EventName { get; set; }
    public int CategoryID { get; set; }
    public string CategoryName { get; set; }
    public string RoleID { get; set; }
    public string RoleName { get; set; }
    public string Status { get; set; }
    public string EventCategoryName
    {
      get => string.Format("{0} ({1})", EventName, CategoryName);
    }
  }
}
