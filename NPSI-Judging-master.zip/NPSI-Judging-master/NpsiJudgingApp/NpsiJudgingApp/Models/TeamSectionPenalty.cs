﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class TeamSectionPenalty : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public int ID { get; set; }
    public DateTimeOffset CreatedDateTime { get; set; }

    private int m_penaltyId;
    public int PenaltyID
    {
      get => m_penaltyId;
      set
      {
        m_penaltyId = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyID)));
      }
    }

    public string JudgeUserID { get; set; }
    public int TeamID { get; set; }
    public int EventID { get; set; }
    public int SectionID { get; set; }
    public string Comments { get; set; }

    private byte[] m_photo;
    public byte[] Photo
    {
      get => m_photo;
      set
      {
        m_photo = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Photo)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PhotoImageSource)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasPhoto)));
      }
    }
    public bool HasPhoto { get => Photo != null; }
    [JsonIgnore]
    public Xamarin.Forms.ImageSource PhotoImageSource
    {
      get
      {
        if (this.Photo == null)
        {
          return null;
        }
        {
          var stream1 = new MemoryStream(this.Photo);
          return Xamarin.Forms.ImageSource.FromStream(() => stream1);
        }
      }
    }

    public string Name { get; set; }

    private decimal m_deduction;
    public decimal Deduction 
    {
      get => m_deduction;
      set 
      {
        m_deduction = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Deduction)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsDeductionInvalid)));
      }
    }


    private decimal? m_deductionMax;
    public decimal? DeductionMax 
    {
      get => m_deductionMax;
      set 
      {
        m_deductionMax = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DeductionMax)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsVariable)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsStatic)));
      }
    }

    public decimal DeductionMin { get; set; }

    private string m_deductionRange;
    public string DeductionRange 
    {
      get => m_deductionRange;
      set 
      {
        m_deductionRange = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DeductionRange)));
      }
    }

    public bool IsVariable { get => this.DeductionMax != null; }
    public bool IsStatic { get => this.DeductionMax == null; }
    public List<PenaltyQuestion> Questions { get; set; }
    private int m_penaltyStatusID;
    public int PenaltyStatusID
    {
      get => m_penaltyStatusID;
      set
      {
        m_penaltyStatusID = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyStatusID)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyStatus)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsStatusPending)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsStatusResolved)));
      }
    }
    public bool IsStatusPending  { get => PenaltyStatusID == Constants.PenaltyStatus.PENDING; }
    public bool IsStatusResolved { get => PenaltyStatusID != Constants.PenaltyStatus.PENDING; }
    public string PenaltyStatus 
    {
      get 
      {
        var status = "";
        switch (PenaltyStatusID)
        {
          case Constants.PenaltyStatus.APPROVED:
            status = "Approved";
            break;
          case Constants.PenaltyStatus.DENIED:
            status = "Denied";
            break;
          case Constants.PenaltyStatus.PENDING:
            status = "Pending";
            break;
        }
        return status;
      }
    }

    public bool IsDeductionInvalid
    {
      get
      {
        bool yn = false;
        if (Deduction > 0)
        {
          yn = true;
          if (Deduction >= DeductionMin && Deduction <= (DeductionMax.HasValue ? DeductionMax.Value : DeductionMin))
          {
            if (Convert.ToInt32(Deduction * 100) % 25 == 0) yn = false;
          }
        }
        return yn;
      }
    }
  }
}
