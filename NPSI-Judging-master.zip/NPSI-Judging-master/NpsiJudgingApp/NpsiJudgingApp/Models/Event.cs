﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class Event
  {
    public string EventID { get; set; }
    public string EventName { get; set; }
  }
}
