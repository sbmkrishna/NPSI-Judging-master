﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class EventTeam
  {
    public int EventID { get; set; }
    public int TeamID { get; set; }
    public int CategoryID { get; set; }
    public string TeamName { get; set; }
    public string CategoryName { get; set; }
    public string SchoolName { get; set; }
    public DateTime Date { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public List<Member> Members { get; set; }
    public List<TeamJudge> Judges { get; set; }
    public bool Done { get; set; }
    public bool NotDone { get => !Done; }

    public List<Subsection> SubsectionScore { get; set; }

    public bool IsReadySubmit
    {
      get => SubsectionScore != null && SubsectionScore.Count > 0 && (SubsectionScore.Where(s => s.IsReadySubmit).Count() == SubsectionScore.Count) && (!Done);
    }

    public DateTime? TimeIn { get; set; }
    public DateTime? TimeOut { get; set; }
    public bool HasTimeInOut 
    {
      get => TimeIn.HasValue || TimeOut.HasValue;
    }
    public DateTime? DateTimeInOut { get; set; }
    public string JudgeUserID { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string PrimaryContactName { get; set; }
    public bool Active { get; set; }
    public int? SortOrder { get; set; }
    public int? PenaltyCount { get; set; }
    public string Comments { get; set; }
    public string CompeteTime
    {
      get => string.Format("{0:g} - {1:t}", StartTime, EndTime);
    }
  }
}
