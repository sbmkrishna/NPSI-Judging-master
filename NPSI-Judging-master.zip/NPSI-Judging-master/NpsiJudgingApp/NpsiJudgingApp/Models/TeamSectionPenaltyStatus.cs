﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class TeamSectionPenaltyStatus
  {
    public int ID { get; set; }
    public int PenaltyStatusID { get; set; }
  }
}
