﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class ScoreModel : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    private int? m_id;
    public int? ID 
    {
      get => m_id;
      set
      {
        m_id = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ID)));
      }
    }

    private decimal? m_score;
    public decimal? Score
    {
      get => m_score;
      set
      {
        m_score = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Score)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsScoreInvalid)));
      }
    }

    private DateTimeOffset m_createDtTm;
    public DateTimeOffset CreatedDateTime 
    {
      get => m_createDtTm;
      set 
      {
        m_createDtTm = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CreatedDateTime)));
      }
    }

    public int SubsectionID { get; set; }
    public string JudgeUserID { get; set; }
    public int TeamID { get; set; }
    public int EventID { get; set; }
    public int SectionID { get; set; }

    private string m_comments;
    public string Comments
    {
      get => m_comments;
      set
      {
        m_comments = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Comments)));
      }
    }

    private byte[] m_photo;
    public byte[] Photo 
    {
      get => m_photo;
      set 
      {
        m_photo = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Photo)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasPhoto)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PhotoImageSource)));
      }
    }
    public bool HasPhoto { get => Photo != null; }

    [JsonIgnore]
    public Xamarin.Forms.ImageSource PhotoImageSource
    {
      get
      {
        if (this.Photo == null) 
        {
          return null;
        }
        {
          var stream1 = new MemoryStream(this.Photo);
          return Xamarin.Forms.ImageSource.FromStream(() => stream1);
        }
      }
    }

    public int MinVal { get; set; }
    public int MaxVal { get; set; }

    public bool IsScoreInvalid
    {
      get
      {
        bool yn = false;
        if (Score.HasValue)
        {
          yn = true;
          if (Score.Value >= MinVal && Score.Value <= MaxVal)
          {
            if (Convert.ToInt32(Score.Value * 100) % 25 == 0) yn = false;
          }
        }
        return yn;
      }
    }
  }
}
