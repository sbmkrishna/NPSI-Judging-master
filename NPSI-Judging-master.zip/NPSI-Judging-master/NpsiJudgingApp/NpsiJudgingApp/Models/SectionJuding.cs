﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.ComponentModel;

namespace NpsiJudgingApp.Models
{
  public class SectionJudging : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public int ID { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public bool Active { get; set; }
    public short CategoryID { get; set; }
    public short? SortOrder { get; set; }
    public string CategoryName { get; set; }

    private List<EventTeam> mo_teams;
    public List<EventTeam> Teams 
    {
      get => mo_teams;
      set 
      {
        mo_teams = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Teams)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsReadySubmit)));
      }
    }

    public bool IsReadySubmit
    {
      get => Teams != null && Teams.Count > 0 && (Teams.Where(t => t.IsReadySubmit).Count() == Teams.Count) && (!SubmittedDateTime.HasValue);
    }

    private DateTimeOffset? m_submittedDateTime;
    public DateTimeOffset? SubmittedDateTime 
    {
      get => m_submittedDateTime;
      set 
      {
        m_submittedDateTime = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SubmittedDateTime)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSubmitted)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsReadySubmit)));
      }
    }

    public bool IsSubmitted
    {
      get => SubmittedDateTime.HasValue;
    }

    public DateTime? StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public DateTime? TimeIn { get; set; }
    public DateTime? TimeOut { get; set; }
    public DateTime? DateTimeInOut { get; set; }
    public bool TimeInOutNeeded { get; set; }
  }
}
