﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class EventSectionTeam
  {
    public int EventID { get; set; }
    public string EventName { get; set; }
    public int SectionID { get; set; }
    public string SectionName { get; set; }
    public int TeamID { get; set; }
    public string TeamName { get; set; }
    public int CategoryID { get; set; }
    public string CategoryName { get; set; }
  }
}
