﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class Subsection : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public int EventID { get; set; }
    public int SectionID { get; set; }
    public int CategoryID { get; set; }
    public int TeamID { get; set; }
    public int SubSectionID { get; set; }
    public string SubSectionName { get; set; }
    public string JudgeUserID { get; set; }
    public string Description { get; set; }
    public int MinScore { get; set; }
    public int MaxScore { get; set; }
    public List<Criteria> Criteria { get; set; }

    private ScoreModel mo_score;
    public ScoreModel Score
    {
      get => mo_score;
      set 
      {
        mo_score = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Score)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsReadySubmit)));
      }
    }

    public bool IsReadySubmit
    {
        get => this.Score != null && this.Score.Score.HasValue && (!string.IsNullOrEmpty(this.Score.Comments));
    }

    public bool HasPhoto { get => (this.Score != null &&  this.Score.Photo != null); }
    public decimal? ScoreConcept { get; set; }
    public int? SortIndex { get; set; }
    public string Excellent { get; set; }
    public string VeryGood { get; set; }
    public string Good { get; set; }
    public string Fair { get; set; }
    public string Poor { get; set; }

    private string m_comments;
    public string Comments 
    {
      get => m_comments;
      set 
      {
        m_comments = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Comments)));
      }
    }

    public byte[] Image { get; set; }
    public string Photo { get; set; }
  }
}
