﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class EventCategoryPenalty : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public int ID { get; set; }
    public DateTimeOffset CreatedDateTime { get; set; }
    public int PenaltyID { get; set; }
    public string Penalty { get; set; }
    public string Comments { get; set; }
    public byte[] Photo { get; set; }
    public int EventID { get; set; }
    public int TeamID { get; set; }
    public string Team { get; set; }
    public string JudgeUserID { get; set; }
    public string JudgeLastName { get; set; }
    public string JudgeFirstName { get; set; }
    public string JudgeUserName { get; set; }
    public int SectionID { get; set; }
    public string Section { get; set; }
    public decimal Deduction { get; set; }
    public decimal DeductionMin { get; set; }
    public decimal? DeductionMax { get; set; }
    public string DeductionRange { get; set; }
    public string UpdatedUserID { get; set; }
    public List<PenaltyQuestion> Questions { get; set; }
    private int m_penaltyStatusID;
    public int PenaltyStatusID
    {
      get => m_penaltyStatusID;
      set
      {
        m_penaltyStatusID = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyStatusID)));
      }
    }

    private bool? m_statusPending;
    public bool IsStatusPending
    {
      get 
      {
        if (m_statusPending == null) m_statusPending = (PenaltyStatusID == Constants.PenaltyStatus.PENDING);
        return m_statusPending.Value;
      }
      set
      {
        m_statusPending = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsStatusPending)));
      }
    }
    private bool? m_statusResolved;
    public bool IsStatusResolved
    {
      get
      {
        if (m_statusResolved == null) m_statusResolved = (PenaltyStatusID != Constants.PenaltyStatus.PENDING);
        return m_statusResolved.Value;
      }
      set
      {
        m_statusResolved = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsStatusResolved)));
      }
    }

    public string StatusCode { get; set; }

    private string m_statusName;
    public string StatusName {
      get => m_statusName;
      set
      {
        m_statusName = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StatusName)));
      }
    }

    public string JudgeName
    {
      get => string.Format("{0} {1}", JudgeFirstName, JudgeLastName);
    }
  }
}
