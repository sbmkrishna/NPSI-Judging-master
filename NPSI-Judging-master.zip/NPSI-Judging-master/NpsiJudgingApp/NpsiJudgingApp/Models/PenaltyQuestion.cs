﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class PenaltyQuestion
  {
    public int PenaltyQuestionID { get; set; }
    public int PenaltyID { get; set; }
    public int QuestionNbr { get; set; }
    public string QuestionText { get; set; }
    public string AnswerType { get; set; }
    public string AnswerText { get; set; }
  }
}
