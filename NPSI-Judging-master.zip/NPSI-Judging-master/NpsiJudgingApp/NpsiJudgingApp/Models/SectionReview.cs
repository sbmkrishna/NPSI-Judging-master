﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class SectionReview
  {
    public int Id { get; set; }
    public string Name { get; set; }
    public short? SortOrder { get; set; }
    public List<EventTeam> Teams { get; set; }
  }
}
