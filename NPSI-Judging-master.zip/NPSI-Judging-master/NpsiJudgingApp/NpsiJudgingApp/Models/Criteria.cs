﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class Criteria
  {
    public string Title { get; set; }
    public string Description { get; set; }
    public int? MaxScore { get; set; }
    public int MinScore { get; set; }
    public int SubsectionId { get; set; }

  }
}
