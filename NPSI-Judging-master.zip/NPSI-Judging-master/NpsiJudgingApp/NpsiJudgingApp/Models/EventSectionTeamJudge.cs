﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class EventSectionTeamJudge : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public int EventID { get; set; }
    public string EventName { get; set; }
    public int CategoryID { get; set; }
    public string CategoryName { get; set; }
    public int SectionID { get; set; }
    public string SectionName { get; set; }
    public int TeamID { get; set; }
    public string TeamName { get; set; }
    public string SchoolName { get; set; }
    public string TeamEmail { get; set; }
    public string TeamPhone { get; set; }
    public bool Active { get; set; }
    public DateTime Date { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public string JudgeUserID { get; set; }
    public string JudgeFirstName { get; set; }
    public string JudgeLastName { get; set; }
    public bool Done { get; set; }
    public bool TimeInOutNeeded { get; set; }

    private DateTime? m_timeIn;
    public DateTime? TimeIn 
    {
      get => m_timeIn;
      set 
      {
        m_timeIn = value;
        if (value.HasValue) m_timeInSpan = value.Value.TimeOfDay;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeIn)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeInSpan)));
      }
    }
    private TimeSpan? m_timeInSpan;
    public TimeSpan? TimeInSpan
    {
      get => m_timeInSpan;
      set 
      {
        m_timeInSpan = value;
        if (value.HasValue) m_timeIn = Convert.ToDateTime(m_timeInSpan.ToString());
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeInSpan)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeIn)));
      }
    }

    private DateTime? m_timeOut;
    public DateTime? TimeOut
    {
      get => m_timeOut;
      set 
      {
        m_timeOut = value;
        if (value.HasValue) m_timeOutSpan = value.Value.TimeOfDay;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeOut)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeOutSpan)));
      }
    }
    private TimeSpan? m_timeOutSpan;
    public TimeSpan? TimeOutSpan
    {
      get => m_timeOutSpan;
      set
      {
        m_timeOutSpan = value;
        if (value.HasValue) m_timeOut = Convert.ToDateTime(m_timeOutSpan.ToString());
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeOutSpan)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeOut)));
      }
    }

    public DateTime? DateTimeInOut { get; set; }
    public int? SortOrder { get; set; }

    private string m_comments;
    public string Comments 
    {
      get => m_comments; 
      set
      {
        m_comments = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Comments)));
      }
    }

    public List<Subsection> SubsectionScores { get; set; }
    public List<TeamSectionPenalty> Penalties { get; set; }
    public List<TeamSectionDisqualification> Disqualifications { get; set; }
  }
}
