﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class Disqualification
  {
    public int? ID { get; set; }
    public string Name { get; set; }
    public bool Active { get; set; }
  }
}
