﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NpsiJudgingApp.Models
{
  public class JudgeSectionTimeInOut
  {
    public int EventID { get; set; }
    public int TeamID { get; set; }
    public int SectionID { get; set; }
    public string JudgeUserID { get; set; }
    public DateTime? TimeIn { get; set; }
    public DateTime? TimeOut { get; set; }
    public string GeneralComments { get; set; }
  }
}
