﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace NpsiJudgingApp.Services
{
  class ApiServices
  {
    public List<Disqualification> GetEventSectionDisqualification(int EventId, int SectionId, int TeamId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getEventSectionDisqualification/{0}/{1}/{2}", EventId, SectionId, TeamId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<Disqualification>>(rsvp);
    }

    public List<Penalty> GetEventSectionPenalty(int EventId, int SectionId, int TeamId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getEventSectionPenalty/{0}/{1}/{2}", EventId, SectionId, TeamId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<Penalty>>(rsvp);
    }

    public void DeleteTeamSectionDisqualification(int ID)
    {
      string endpoint = string.Format("event/deleteTeamSectionDisqualification/{0}", ID);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Delete, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
          {
            response.EnsureSuccessStatusCode();
          }
        }
      }
    }

    public void DeleteTeamSectionPenalty(int ID)
    {
      string endpoint = string.Format("event/deleteTeamSectionPenalty/{0}", ID);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Delete, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
          {
            response.EnsureSuccessStatusCode();
          }
        }
      }
    }

    public int AddEditScore(Subsection subsectionModel)
    {
      string endpoint = "event/addEditScore";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(subsectionModel);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              _ = response.EnsureSuccessStatusCode();
              return Convert.ToInt32(response.Content.ReadAsStringAsync().Result);
            }
          }
        }
      }
    }

    public void InsertTeamSectionDisqualification(TeamSectionDisqualification teamSectionDisqualification)
    {
      string endpoint = "event/addTeamSectionDisqualification";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(teamSectionDisqualification);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public void InsertTeamSectionPenalty(TeamSectionPenalty teamSectionPenalty)
    {
      string endpoint = "event/addTeamSectionPenalty";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(teamSectionPenalty);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public void SubmitScores(int EventId, int SectionId, int CategoryId)
    {
      string endpoint = string.Format("event/submitScore/{0}/{1}/{2}", EventId, SectionId, CategoryId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Put, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
          {
            response.EnsureSuccessStatusCode();
          }
        }
      }
    }

    public void UpdateTeamSectionDisqualification(TeamSectionDisqualification teamSectionDisqualification)
    {
      string endpoint = "event/editTeamSectionDisqualification";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Put, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(teamSectionDisqualification);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public void UpdateTeamSectionPenalty(TeamSectionPenalty teamSectionPenalty)
    {
      string endpoint = "event/editTeamSectionPenalty";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Put, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(teamSectionPenalty);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public void UpdateJudgeSectionTimeInOut(JudgeSectionTimeInOut judgeSectionTimeInOut)
    {
      string endpoint = "event/addUpdateJudgeSectionTimeInOut";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(judgeSectionTimeInOut);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public void UpdateJudgeSectionComment(JudgeSectionTimeInOut judgeSectionTimeInOut)
    {
      string endpoint = "event/addUpdateJudgeSectionComment";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(judgeSectionTimeInOut);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response = client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }      

    public EventSectionTeamJudge GetEventSectionTeamDetail(int EventId, int SectionId, int TeamId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getEventSectionTeamDetail/{0}/{1}/{2}", EventId, SectionId, TeamId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<EventSectionTeamJudge>(rsvp);
    }

    public void UpdateTeamSectionPenaltyStatus(TeamSectionPenaltyStatus teamSectionPenaltyStatus)
    {
      string endpoint = "event/editTeamSectionPenaltyStatus";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          var json = JsonConvert.SerializeObject(teamSectionPenaltyStatus);
          using (var stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
          {
            request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
            request.Content = stringContent;
            using (var response =  client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).Result)
            {
              response.EnsureSuccessStatusCode();
            }
          }
        }
      }
    }

    public List<EventCategoryPenalty> GetEventCategoryPenalties(int EventId, int CategoryId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getEventCategoryPenalties/{0}/{1}", EventId, CategoryId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<EventCategoryPenalty>>(rsvp);
    }

    public List<TeamSectionDisqualification> GetTeamSectionDisqualifications(int EventId, int SectionId, int TeamId, string JudgeId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getTeamSectionDisqualification/{0}/{1}/{2}?judgeID={3}", EventId, SectionId, TeamId, JudgeId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<TeamSectionDisqualification>>(rsvp);
    }

    public List<TeamSectionPenalty> GetTeamSectionPenalties(int EventId, int SectionId, int TeamId, string JudgeId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getTeamSectionPenalties/{0}/{1}/{2}?judgeID={3}", EventId, SectionId, TeamId, JudgeId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<TeamSectionPenalty>>(rsvp);
    }


    public List<Subsection>GetSubsectionByEventSectionAndTeam(int EventId, int SectionId, int TeamId, string JudgeId, int CategoryId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getSubsectionByEventSectionAndTeam/{0}/{1}/{2}?categoryID={3}&judgeID={4}", EventId, SectionId, TeamId, CategoryId, JudgeId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<Subsection>>(rsvp);
    }

    public TeamSectionDetail GetTeamSectionDetail(int EventId, int SectionId, int TeamId, string JudgeId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getTeamSectionDetail//{0}/{1}/{2}?judgeID={3}", EventId, SectionId, TeamId, JudgeId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<TeamSectionDetail>(rsvp);
    }

    public List<SectionReview> GetSectionReview(int EventId, int CategoryId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getEventRun/{0}/{1}", EventId, CategoryId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<SectionReview>>(rsvp);
    }

    public List<SectionJudging> GetEventCategorySections(int EventId, int CategoryId)
    {
      HttpResponseMessage response;
      string endpoint = string.Format("event/getSectionUserByEventandCategory/{0}/{1}", EventId, CategoryId);

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<SectionJudging>>(rsvp);
    }

    public List<EventCategory> GetEventCategories()
    {
      HttpResponseMessage response;
      string endpoint = "event/GetUserEventCategoryList";

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<EventCategory>>(rsvp);
    }

    public List<Event> GetEventList(string EventStatus)
    {
      HttpResponseMessage response;
      string endpoint = "";
      switch (EventStatus)
      {
        case "A": endpoint = "event/getEventActiveByUserID"; break;
        case "C": endpoint = "event/getEventCompleteByUserID"; break;
        case "S": endpoint = "event/getEventStartedByUserID"; break;
      }

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + endpoint))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = client.SendAsync(request).Result;
        }
      }

      var rsvp = response.Content.ReadAsStringAsync().Result;
      return JsonConvert.DeserializeObject<List<Event>>(rsvp);
    }

    public async Task<AspNetUser> GetUserInfo()
    {
      HttpResponseMessage response;

      using (var client = new HttpClient())
      {
        using (var request = new HttpRequestMessage(HttpMethod.Get, AppSettingsManager.AppSettings["BaseApi"] + "account/getUserInfo"))
        {
          request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          request.Headers.Add("Authorization", string.Format("Bearer {0}", Settings.AccessToken));
          response = await client.SendAsync(request);
        }
      }

      var rsvp = await response.Content.ReadAsStringAsync();
      return JsonConvert.DeserializeObject<AspNetUser>(rsvp);
    }

    public async Task<AuthToken> LoginAsync(string userName, string password)
    {
      var keyValues = new List<KeyValuePair<string, string>>
      {
        new KeyValuePair<string, string>("username", userName),
        new KeyValuePair<string, string>("password", password),
        new KeyValuePair<string, string>("grant_type", "password")
      };

      var request = new HttpRequestMessage(HttpMethod.Post, AppSettingsManager.AppSettings["BaseUrl"] + "oauth/token");

      request.Content = new FormUrlEncodedContent(keyValues);
      request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");

      var client = new HttpClient();
      var response = await client.SendAsync(request);
      request.Dispose();

      var jwt = await response.Content.ReadAsStringAsync();
      JObject jwtDynamic = JsonConvert.DeserializeObject<dynamic>(jwt);

      var adt = new AuthToken();
      adt.ExpiresIn = jwtDynamic.Value<double>("expires_in");
      adt.TokenType = jwtDynamic.Value<string>("token_type");
      adt.AccessToken = jwtDynamic.Value<string>("access_token");

      return adt;
    }
  }
}
