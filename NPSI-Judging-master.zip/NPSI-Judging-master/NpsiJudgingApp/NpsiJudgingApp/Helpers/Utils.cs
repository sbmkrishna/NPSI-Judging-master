﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NpsiJudgingApp.Helpers
{
  public static class Utils
  {
    public static byte[] StreamToByteArray(Stream input)
    {
      using (MemoryStream ms = new MemoryStream())
      {
        input.CopyTo(ms);
        return ms.ToArray();
      }
    }
  }
}
