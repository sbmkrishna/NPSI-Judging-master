﻿// Helpers/Settings.cs
using Plugin.Settings;
using Plugin.Settings.Abstractions;
using System;
using Newtonsoft.Json;

namespace NpsiJudgingApp.Helpers
{
  public static class Settings
  {
    private static ISettings AppSettings
    {
      get
      {
        return CrossSettings.Current;
      }
    }

    public static string AccessToken
    {
      get
      {
        return AppSettings.GetValueOrDefault("AccessToken", "");
      }
      set
      {
        AppSettings.AddOrUpdateValue("AccessToken", value);
      }
    }

    public static DateTime AccessTokenExpirationDate
    {
      get
      {
        return AppSettings.GetValueOrDefault("AccessTokenExpirationDate", DateTime.UtcNow);
      }
      set
      {
        AppSettings.AddOrUpdateValue("AccessTokenExpirationDate", value);
      }
    }

    public static Models.AspNetUser UserInfo
    {
      get
      {
        return JsonConvert.DeserializeObject<Models.AspNetUser>(AppSettings.GetValueOrDefault("UserInfo", ""));
      }
      set
      {
        AppSettings.AddOrUpdateValue("UserInfo", JsonConvert.SerializeObject(value));
      }
    }

  }
}
