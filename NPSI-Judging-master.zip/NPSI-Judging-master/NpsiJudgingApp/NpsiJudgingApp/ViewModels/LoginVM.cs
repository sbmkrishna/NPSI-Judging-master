﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using NpsiJudgingApp.Models;
using System;
using System.ComponentModel;

namespace NpsiJudgingApp.ViewModels
{
  public class LoginVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();

    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    private string m_username;
    private string m_password;
    private string m_lastError;

    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        var args = new PropertyChangedEventArgs(nameof(IsBusy));
        PropertyChanged?.Invoke(this, args);
      }
    }

    public string Username
    {
      get => m_username;
      set
      {
        m_username = value;
        var args = new PropertyChangedEventArgs(nameof(Username));
        PropertyChanged?.Invoke(this, args);
      }
    }

    public string Password
    {
      get => m_password;
      set
      {
        m_password = value;
        var args = new PropertyChangedEventArgs(nameof(Password));
        PropertyChanged?.Invoke(this, args);
      }
    }

    public string LastError
    {
      get => m_lastError;
      set
      {
        m_lastError = value;
        var args = new PropertyChangedEventArgs(nameof(LastError));
        PropertyChanged?.Invoke(this, args);
      }
    }

    public Command LoginCommand
    {
      get
      {
        return new Command(async () =>
        {
          IsBusy = true;
          try
          {
            this.LastError = string.Empty;
            AuthToken adt = await _apiServices.LoginAsync(Username, Password);
            if (adt.AccessToken == null)
              throw new Exception("Username and password are incorrect.");
            else
            {
              // save the token and expiration in the settings
              Settings.AccessToken = adt.AccessToken;
              Settings.AccessTokenExpirationDate = DateTime.Now.AddSeconds(adt.ExpiresIn);

              // get the rest of the user info
              Settings.UserInfo = await _apiServices.GetUserInfo();

              // if everything's ok, move on to dashboard
              var eventPage = new Views.EventMenu();
              //var eventVM = new EventMenuVM();
              //eventPage.BindingContext = eventVM;
              await Application.Current.MainPage.Navigation.PushAsync(eventPage);
            }
          }
          catch (Exception ex)
          {
            this.LastError = ex.Message;
          }
          IsBusy = false;
        });
      }
    }
  }
}
