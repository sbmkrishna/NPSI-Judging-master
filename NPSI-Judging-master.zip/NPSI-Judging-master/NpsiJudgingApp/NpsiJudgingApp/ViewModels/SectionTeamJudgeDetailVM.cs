﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;
using System.Linq;
using Rg.Plugins.Popup.Services;

namespace NpsiJudgingApp.ViewModels
{
  public class SectionTeamJudgeDetailVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsBusy)));
      }
    }

    private Models.SectionTeam m_currentSectionTeam;
    public Models.SectionTeam CurrentSectionTeam
    {
      get => m_currentSectionTeam;
      set
      {
        m_currentSectionTeam = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentSectionTeam)));
      }
    }


    private Models.TeamSectionDetail m_teamSectionDetail;
    public Models.TeamSectionDetail TeamSection
    {
      get => m_teamSectionDetail;
      set
      {
        m_teamSectionDetail = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TeamSection)));
      }
    }

    private ObservableCollection<Models.Subsection> m_subsections;
    public ObservableCollection<Models.Subsection> Subsections
    {
      get => m_subsections;
      set
      {
        m_subsections = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Subsections)));
      }
    }

    private ObservableCollection<Models.TeamSectionDisqualification> m_disqualifications;
    public ObservableCollection<Models.TeamSectionDisqualification> Disqualifications
    {
      get => m_disqualifications;
      set
      {
        m_disqualifications = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Disqualifications)));
      }
    }
    public bool HasDisqualifications { get => (Disqualifications.Count > 0); }
    public bool NoDisqualifications { get => (Disqualifications.Count == 0); }


    private ObservableCollection<Models.TeamSectionPenalty> m_penalties;
    public ObservableCollection<Models.TeamSectionPenalty> Penalties
    {
      get => m_penalties;
      set
      {
        m_penalties = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Penalties)));
      }
    }
    public bool HasPenalties { get => (Penalties.Count > 0); }
    public bool NoPenalties { get => (Penalties.Count == 0); }


    public ICommand TapViewImageCommand
    {
      get
      {
        return new Command<byte[]>(async (eventPhoto) =>
        {
          try
          {
            // make sure there's a valid image
            if (eventPhoto == null) throw new Exception("There is a problem with this image file.");
            // navigate to new page
            var popup = new Views.PopupImage(eventPhoto);
            popup.CloseWhenBackgroundIsClicked = true;
            await PopupNavigation.Instance.PushAsync(popup);
          }
          catch(Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapPenaltyApprove
    {
      get
      {
        return new Command<Models.TeamSectionPenalty>(async (penalty) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Approve Penalty", "This will approve the selected penalty and include it in the team's score. This operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            var teamSectionPenaltyStatus = new Models.TeamSectionPenaltyStatus() { ID = penalty.ID, PenaltyStatusID = Constants.PenaltyStatus.APPROVED };
            _apiServices.UpdateTeamSectionPenaltyStatus(teamSectionPenaltyStatus);
            Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID));
          }
          IsBusy = false;
        });
      }
    }

    public ICommand TapPenaltyDeny
    {
      get
      {
        return new Command<Models.TeamSectionPenalty>(async (penalty) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Deny Penalty", "This will deny the selected penalty and it will not be counted in the the team's score. This operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            var teamSectionPenaltyStatus = new Models.TeamSectionPenaltyStatus() { ID = penalty.ID, PenaltyStatusID = Constants.PenaltyStatus.DENIED };
            _apiServices.UpdateTeamSectionPenaltyStatus(teamSectionPenaltyStatus);
            Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID));
          }
          IsBusy = false;
        });
      }
    }

    public SectionTeamJudgeDetailVM(Models.SectionTeam MySectionTeam)
    {
      // initialize view
      IsBusy = true;
      CurrentSectionTeam = MySectionTeam;

      // load data from server 
      TeamSection = _apiServices.GetTeamSectionDetail(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID);
      var baseSubsectionList = _apiServices.GetSubsectionByEventSectionAndTeam(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID, CurrentSectionTeam.CategoryID);
      Subsections = new ObservableCollection<Models.Subsection>(baseSubsectionList.OrderBy(s => s.SortIndex == 0 || s.SortIndex == null ? 999 : s.SortIndex));
      Disqualifications = new ObservableCollection<Models.TeamSectionDisqualification>(_apiServices.GetTeamSectionDisqualifications(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID));
      Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentSectionTeam.EventID, CurrentSectionTeam.SectionID, CurrentSectionTeam.TeamID, CurrentSectionTeam.JudgeID));

      IsBusy = false;
    }
  }
}
