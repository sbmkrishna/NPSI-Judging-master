﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;
using System.Linq;
using Rg.Plugins.Popup.Services;

namespace NpsiJudgingApp.ViewModels
{
  public class TeamSectionFormVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsBusy)));
      }
    }

    private Models.EventSectionTeam m_currentEventTeam;
    public Models.EventSectionTeam CurrentEventTeam
    {
      get => m_currentEventTeam;
      set
      {
        m_currentEventTeam = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentEventTeam)));
      }
    }


    private Models.EventSectionTeamJudge m_currentDetail;
    public Models.EventSectionTeamJudge CurrentDetail
    {
      get => m_currentDetail;
      set
      {
        m_currentDetail = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentDetail)));
      }
    }

    private ObservableCollection<Models.TeamSectionPenalty> m_penalties;
    public ObservableCollection<Models.TeamSectionPenalty> Penalties
    {
      get => m_penalties;
      set
      {
        m_penalties = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Penalties)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasPenalties)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoPenalties)));
      }
    }
    public bool HasPenalties { get => (Penalties.Count > 0); }
    public bool NoPenalties { get => (Penalties.Count == 0); }


    private ObservableCollection<Models.TeamSectionDisqualification> m_disqualifications;
    public ObservableCollection<Models.TeamSectionDisqualification> Disqualifications
    {
      get => m_disqualifications;
      set
      {
        m_disqualifications = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Disqualifications)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasDisqualifications)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoDisqualifications)));
      }
    }
    public bool HasDisqualifications { get => (Disqualifications.Count > 0); }
    public bool NoDisqualifications { get => (Disqualifications.Count == 0); }


    public Command SaveTimeInOut
    {
      get 
      {
        return new Command(() =>
        {
          //Application.Current.MainPage.DisplayAlert("TimeInOut", string.Format("Time in: {0:t}", CurrentDetail.TimeIn), "OK");
          IsBusy = true;
          var jsm = new Models.JudgeSectionTimeInOut()
          {
            EventID = CurrentDetail.EventID,
            GeneralComments = CurrentDetail.Comments,
            JudgeUserID = CurrentDetail.JudgeUserID,
            SectionID = CurrentDetail.SectionID,
            TeamID = CurrentDetail.TeamID,
            TimeIn = CurrentDetail.TimeIn,
            TimeOut = CurrentDetail.TimeOut
          };

          try
          {
            _apiServices.UpdateJudgeSectionTimeInOut(jsm);
          }
          catch (Exception ex)
          {
            Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
          IsBusy = false;
        });
      }
    }


    public Command SaveGeneralComments
    {
      get
      {
        return new Command(() =>
        {
          IsBusy = true;
          var jsm = new Models.JudgeSectionTimeInOut()
          {
            EventID = CurrentDetail.EventID,
            GeneralComments = CurrentDetail.Comments,
            JudgeUserID = CurrentDetail.JudgeUserID,
            SectionID = CurrentDetail.SectionID,
            TeamID = CurrentDetail.TeamID,
            TimeIn = CurrentDetail.TimeIn,
            TimeOut = CurrentDetail.TimeOut
          };

          try
          {
            _apiServices.UpdateJudgeSectionComment(jsm);
          }
          catch (Exception ex)
          {
            Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
          IsBusy = false;
          //Application.Current.MainPage.DisplayAlert("Testing", CurrentDetail.Comments, "Cancel");
        });
      }
    }

    public ICommand SaveScore
    {
      get
      {
        return new Command<Models.Subsection>((subsectionScore) =>
        {
          try
          {
            if (!subsectionScore.Score.IsScoreInvalid)
            {
              var scoreId = _apiServices.AddEditScore(subsectionScore);
              subsectionScore.Score.ID = scoreId;
            }
          }
          catch (Exception ex)
          {
            Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand SaveSubsectionComment
    {
      get
      {
        return new Command<Models.Subsection>((subsectionScore) =>
        {
          try
          {
            if (subsectionScore.Score.IsScoreInvalid) subsectionScore.Score.Score = null;

            var scoreId = _apiServices.AddEditScore(subsectionScore);
            subsectionScore.Score.ID = scoreId;
          }
          catch (Exception ex)
          {
            Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
        });
      }
    }
    
    public ICommand RemovePicture
    {
      get 
      {
        return new Command<Models.Subsection>(async (subsectionScore) => { 
          try
          {
            bool answer = await Application.Current.MainPage.DisplayAlert("Remove Photo", "This will remove the current photo from the score entry.", "OK", "Cancel");
            if (answer)
            {
              subsectionScore.Score.Photo = null;
              var scoreId = _apiServices.AddEditScore(subsectionScore);
              subsectionScore.Score.ID = scoreId;
            }
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TakePicture
    {
      get
      {
        return new Command<Models.Subsection>(async (subsectionScore) =>
        {
          try
          {
            var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions() { });
            subsectionScore.Score.Photo = Utils.StreamToByteArray(photo.GetStream());

            var scoreId = _apiServices.AddEditScore(subsectionScore);
            subsectionScore.Score.ID = scoreId;
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapViewDescription
    {
      get
      {
        return new Command<Models.Subsection>(async (subsectionScore) =>
        {
          try
          {
            // navigate to new page
            var popup = new Views.PopupHtmlLabel("Description/Notes", subsectionScore.Description);
            popup.CloseWhenBackgroundIsClicked = true;
            await PopupNavigation.Instance.PushAsync(popup);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapViewCriteria
    {
      get
      {
        return new Command<Models.Subsection>(async (subsectionScore) =>
        {
          try
          {
            // navigate to new page
            var eventPage = new Views.PopupSubsectionCriteria();
            var eventVM = new PopupSubsectionCriteriaVM(subsectionScore.Criteria);
            eventPage.BindingContext = eventVM;
            await PopupNavigation.Instance.PushAsync(eventPage);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapViewImageCommand
    {
      get
      {
        return new Command<byte[]>(async (eventPhoto) =>
        {
          try
          {
            // make sure there's a valid image
            if (eventPhoto == null) throw new Exception("There is a problem with this image file.");
            // navigate to new page
            var popup = new Views.PopupImage(eventPhoto);
            popup.CloseWhenBackgroundIsClicked = true;
            await PopupNavigation.Instance.PushAsync(popup);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapDisqualificationAdd
    {
      get 
      {
        return new Command(async () =>
        {
          IsBusy = true;
          try
          {
            // set up emtpy disqualification
            Models.TeamSectionDisqualification disqual = new Models.TeamSectionDisqualification()
            {
              EventID = CurrentEventTeam.EventID,
              JudgeUserID = CurrentDetail.JudgeUserID,
              TeamID = CurrentEventTeam.TeamID,
              SectionID = CurrentDetail.SectionID,
              ID = 0
            };
            // open in form
            var eventPage = new Views.PopupDisqualificationForm();
            var eventVM = new PopupDisqualificationFormVM(disqual);
            eventVM.DisqualificationUpdatedEvent += (refreshYn) =>
            {
              if (refreshYn) Disqualifications = new ObservableCollection<Models.TeamSectionDisqualification>(_apiServices.GetTeamSectionDisqualifications(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
              IsBusy = false;
            };

            eventPage.BindingContext = eventVM;
            await PopupNavigation.Instance.PushAsync(eventPage);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapPenaltyAdd
    {
      get
      {
        return new Command(async () =>
        {
          IsBusy = true;
          try
          {
            // set up empty penalty
            Models.TeamSectionPenalty penalty = new Models.TeamSectionPenalty()
            {
              EventID = CurrentEventTeam.EventID,
              JudgeUserID = CurrentDetail.JudgeUserID,
              TeamID = CurrentEventTeam.TeamID,
              SectionID = CurrentDetail.SectionID,
              ID = 0,
              Questions = new List<Models.PenaltyQuestion>()
            };
            // open in form
            var eventPage = new Views.PopupPenaltyForm();
            var eventVM = new PopupPenaltyFormVM(penalty);
            eventVM.PenaltyUpdatedEvent += (refreshYn) =>
            {
              if (refreshYn) Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
              IsBusy = false;
            };

            eventPage.BindingContext = eventVM;
            await PopupNavigation.Instance.PushAsync(eventPage);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapDisqualificationEdit
    {
      get
      {
        return new Command<Models.TeamSectionDisqualification>(async (disqual) =>
        {
          IsBusy = true;
          try
          {
            // open in form
            var eventPage = new Views.PopupDisqualificationForm();
            var eventVM = new PopupDisqualificationFormVM(disqual);
            eventVM.DisqualificationUpdatedEvent += (refreshYn) =>
            {
              if (refreshYn) Disqualifications = new ObservableCollection<Models.TeamSectionDisqualification>(_apiServices.GetTeamSectionDisqualifications(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
              IsBusy = false;
            };

            eventPage.BindingContext = eventVM;
            await PopupNavigation.Instance.PushAsync(eventPage);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapPenaltyEdit
    {
      get
      {
        return new Command<Models.TeamSectionPenalty>(async (penalty) =>
        {
          IsBusy = true;
          try
          {
            // open in form
            var eventPage = new Views.PopupPenaltyForm();
            var eventVM = new PopupPenaltyFormVM(penalty);
            eventVM.PenaltyUpdatedEvent += (refreshYn) =>
            {
              if (refreshYn) Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
              IsBusy = false;
            };

            eventPage.BindingContext = eventVM;
            await PopupNavigation.Instance.PushAsync(eventPage);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public ICommand TapDisqualificationDelete
    {
      get
      {
        return new Command<Models.TeamSectionDisqualification>(async (disqual) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Delete Disqualification", "This will delete the selected disqualification. The operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            try
            {
              _apiServices.DeleteTeamSectionDisqualification(disqual.ID);
              Disqualifications.Remove(disqual);
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Disqualifications)));
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasDisqualifications)));
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoDisqualifications)));
            }
            catch (Exception ex)
            {
              await Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
            }
          }
          IsBusy = false;
        });
      }
    }

    public ICommand TapPenaltyDelete
    {
      get
      {
        return new Command<Models.TeamSectionPenalty>(async (penalty) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Delete Penalty", "This will delete the selected penalty. The operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            try
            {
              _apiServices.DeleteTeamSectionPenalty(penalty.ID);
              Penalties.Remove(penalty);
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Penalties)));
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasPenalties)));
              PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoPenalties)));
            }
            catch (Exception ex)
            {
              await Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
            }
          }
          IsBusy = false;
        });
      }
    }

    public TeamSectionFormVM(Models.EventSectionTeam MyEventTeam)
    {
      IsBusy = true;
      CurrentEventTeam = MyEventTeam;
      CurrentDetail = _apiServices.GetEventSectionTeamDetail(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID);
      Penalties = new ObservableCollection<Models.TeamSectionPenalty>(_apiServices.GetTeamSectionPenalties(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
      Disqualifications = new ObservableCollection<Models.TeamSectionDisqualification>(_apiServices.GetTeamSectionDisqualifications(CurrentEventTeam.EventID, CurrentEventTeam.SectionID, CurrentEventTeam.TeamID, CurrentDetail.JudgeUserID));
      IsBusy = false;
    }
  }
}
