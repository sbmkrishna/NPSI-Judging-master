﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace NpsiJudgingApp.ViewModels
{
  public class LeadJudgeMenuVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();

    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsBusy)));
      }
    }

    private Models.EventCategory m_currentEvent;
    public Models.EventCategory CurrentEvent
    {
      get => m_currentEvent;
      set
      {
        m_currentEvent = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentEvent)));
      }
    }

    public ICommand TapCommand
    {
      get
      {
        return new Command<string>(async (ItemName) =>
        {
          IsBusy = true;
          Page eventPage;
          switch (ItemName)
          {
            case "category":
              eventPage = new Views.EventReview();
              var eventVM = new EventReviewVM(CurrentEvent);
              eventPage.BindingContext = eventVM;
              await Application.Current.MainPage.Navigation.PushAsync(eventPage);
              break;
          }
          IsBusy = false;
          //await Application.Current.MainPage.DisplayAlert("Testing", ItemName, "Cancel");
        });
      }
    }

    public LeadJudgeMenuVM()
    {

    }

    public LeadJudgeMenuVM(Models.EventCategory MyEvent)
    {
      CurrentEvent = MyEvent;
      IsBusy = false;
    }
  }
}
