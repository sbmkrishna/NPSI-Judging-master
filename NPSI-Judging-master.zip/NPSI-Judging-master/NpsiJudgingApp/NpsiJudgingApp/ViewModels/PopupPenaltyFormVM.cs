﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using NpsiJudgingApp.Services;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;
using Rg.Plugins.Popup.Services;

namespace NpsiJudgingApp.ViewModels
{
  public class PopupPenaltyFormVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    public delegate void PenaltyUpdated(bool NeedRefresh);
    public event PenaltyUpdated PenaltyUpdatedEvent;

    private Models.TeamSectionPenalty mo_currentTeamPenalty;
    public Models.TeamSectionPenalty CurrentTeamPenalty
    {
      get => mo_currentTeamPenalty;
      set 
      {
        mo_currentTeamPenalty = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentTeamPenalty)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsNew)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsExisting)));
      }
    }
    public bool IsNew { get => (CurrentTeamPenalty.ID == 0); }
    public bool IsExisting { get => (CurrentTeamPenalty.ID != 0); }


    private ObservableCollection<Models.Penalty> mo_penaltyList;
    public ObservableCollection<Models.Penalty> PenaltyList
    {
      get => mo_penaltyList;
      set
      {
        mo_penaltyList = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyList)));
      }
    }

    private Models.Penalty mo_selectedPenalty;
    public Models.Penalty SelectedPenalty
    {
      get => mo_selectedPenalty;
      set 
      {
        mo_selectedPenalty = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedPenalty)));
        CurrentTeamPenalty.PenaltyID = mo_selectedPenalty.ID.Value;
        CurrentTeamPenalty.PenaltyStatusID = Constants.PenaltyStatus_Pending;
        CurrentTeamPenalty.DeductionMin = mo_selectedPenalty.DeductionMin;
        CurrentTeamPenalty.DeductionMax = mo_selectedPenalty.DeductionMax;
        CurrentTeamPenalty.DeductionRange = mo_selectedPenalty.DeductionRange;
        if (CurrentTeamPenalty.IsStatic)
          CurrentTeamPenalty.Deduction = mo_selectedPenalty.DeductionMin;
        else
          CurrentTeamPenalty.Deduction = 0;
      }
    }

    public ICommand SavePenalty
    {
      get
      {
        return new Command(async () =>
        {
          try
          {
            if (CurrentTeamPenalty.IsDeductionInvalid) throw new Exception("Deduction value is invalid for this type of penalty.");
            if (string.IsNullOrEmpty(CurrentTeamPenalty.Comments)) throw new Exception("Comments are required for every penalty.");

            if (CurrentTeamPenalty.ID == 0)
              _apiServices.InsertTeamSectionPenalty(CurrentTeamPenalty);
            else
              _apiServices.UpdateTeamSectionPenalty(CurrentTeamPenalty);
            PenaltyUpdatedEvent?.Invoke(true);
            await PopupNavigation.Instance.PopAsync();
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
          //Application.Current.MainPage.DisplayAlert("Testing", Newtonsoft.Json.JsonConvert.SerializeObject(CurrentTeamPenalty), "Cancel");
        });
      }
    }

    public ICommand CancelPenalty
    {
      get
      {
        return new Command(async () =>
        {
          PenaltyUpdatedEvent?.Invoke(false);
          await PopupNavigation.Instance.PopAsync();
        });
      }
    }

    public PopupPenaltyFormVM(Models.TeamSectionPenalty MyTeamPenalty)
    {
      CurrentTeamPenalty = MyTeamPenalty;
      PenaltyList = new ObservableCollection<Models.Penalty>(_apiServices.GetEventSectionPenalty(CurrentTeamPenalty.EventID, CurrentTeamPenalty.SectionID, CurrentTeamPenalty.TeamID));
    }
  }
}
