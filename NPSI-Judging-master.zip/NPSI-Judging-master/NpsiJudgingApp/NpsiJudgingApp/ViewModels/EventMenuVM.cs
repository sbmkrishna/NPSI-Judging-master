﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System;

namespace NpsiJudgingApp.ViewModels
{
  public class EventMenuVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();

    public event PropertyChangedEventHandler PropertyChanged;

    public ObservableCollection<Models.EventCategory> EventsActive { get; set; }
    public ObservableCollection<Models.EventCategory> EventsStarted { get; set; }
    public ObservableCollection<Models.EventCategory> EventsCompleted { get; set; }

    private int m_gridHeightActive;
    public int GridHeightActive
    {
      get => m_gridHeightActive;
      set
      {
        m_gridHeightActive = value;
        var args = new PropertyChangedEventArgs(nameof(GridHeightActive));
        PropertyChanged?.Invoke(this, args);
      }
    }

    private int m_gridHeightCompleted;
    public int GridHeightCompleted 
    {
      get => m_gridHeightCompleted;
      set 
      {
        m_gridHeightCompleted = value;
        var args = new PropertyChangedEventArgs(nameof(GridHeightCompleted));
        PropertyChanged?.Invoke(this, args);
      }
    }

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        var args = new PropertyChangedEventArgs(nameof(IsBusy));
        PropertyChanged?.Invoke(this, args);
      }
    }

    private Models.EventCategory m_selectedEventActive;
    public Models.EventCategory SelectedEventActive
    {
      get => m_selectedEventActive;
      set
      {
        IsBusy = true;
        m_selectedEventActive = value;
        var args = new PropertyChangedEventArgs(nameof(SelectedEventActive));
        PropertyChanged?.Invoke(this, args);
      }
    }
    public Command EventsActiveChangedCommand
    {
      get
      {
        return new Command(async () =>
        {
          if (SelectedEventActive != null)
          {
            try
            {
              Page eventPage;
              // if everything's ok, move on to dashboard
              if (SelectedEventActive.RoleName == Constants.Role.LEAD)
              {
                eventPage = new Views.EventReview();
                var eventVM = new EventReviewVM(SelectedEventActive);
                eventPage.BindingContext = eventVM;
              }
              else
              {
                eventPage = new Views.EventDetail();
                var eventVM = new EventDetailVM(SelectedEventActive);
                eventPage.BindingContext = eventVM;
              }

              await Application.Current.MainPage.Navigation.PushAsync(eventPage);
            }
            catch(Exception ex)
            {
              await Application.Current.MainPage.DisplayAlert("Load Error", ex.Message, "OK");
            }
            SelectedEventActive = null;
            SelectedEventCompleted = null;
          }
          IsBusy = false;
        });
      }
    }

    private Models.EventCategory m_selectedEventCompleted;
    public Models.EventCategory SelectedEventCompleted
    {
      get => m_selectedEventCompleted;
      set
      {
        IsBusy = true;
        m_selectedEventCompleted = value;
        var args = new PropertyChangedEventArgs(nameof(SelectedEventCompleted));
        PropertyChanged?.Invoke(this, args);
      }
    }
    public Command EventsCompletedChangedCommand
    {
      get
      {
        return new Command(async () =>
        {
          if (SelectedEventCompleted != null)
          {
            try
            {
              Page eventPage;
              // if everything's ok, move on to dashboard
              if (SelectedEventCompleted.RoleName == Constants.Role.LEAD)
              {
                eventPage = new Views.EventReview();
                var eventVM = new EventReviewVM(SelectedEventCompleted);
                eventPage.BindingContext = eventVM;
              }
              else
              {
                eventPage = new Views.EventDetail();
                var eventVM = new EventDetailVM(SelectedEventCompleted);
                eventPage.BindingContext = eventVM;
              }

              await Application.Current.MainPage.Navigation.PushAsync(eventPage);
            }
            catch (Exception ex)
            {
              await Application.Current.MainPage.DisplayAlert("Load Error", ex.Message, "OK");
            }
            SelectedEventActive = null;
            SelectedEventCompleted = null;
          }
          IsBusy = false;
        });
      }
    }

    public EventMenuVM()
    {
      IsBusy = true;
      List<Models.EventCategory> eventCategories = _apiServices.GetEventCategories();

      EventsActive = new ObservableCollection<Models.EventCategory>(eventCategories.Where(ec => ec.Status == Constants.EventStatus.ACTIVE).ToList());
      GridHeightActive = 62 + ((EventsActive.Count == 0 ? 1 : EventsActive.Count) * 40) + 2;

      EventsStarted = new ObservableCollection<Models.EventCategory>(eventCategories.Where(ec => ec.Status == Constants.EventStatus.STARTED).ToList());

      EventsCompleted = new ObservableCollection<Models.EventCategory>(eventCategories.Where(ec => ec.Status == Constants.EventStatus.COMPLETED).ToList());
      GridHeightCompleted = 62 + ((EventsCompleted.Count == 0 ? 1 : EventsCompleted.Count) * 40) + 2;

      IsBusy = false;
    }
  }
}
