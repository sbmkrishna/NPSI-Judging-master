﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;
using System.Linq;

namespace NpsiJudgingApp.ViewModels
{
  public class EventReviewVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsBusy)));
      }
    }


    private Models.EventCategory m_currentEvent;
    public Models.EventCategory CurrentEvent
    {
      get => m_currentEvent;
      set
      {
        m_currentEvent = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentEvent)));
      }
    }
    private SearchModel m_currentSearchModel;
    public SearchModel CurrentSearchModel
    {
      get => m_currentSearchModel;
      set
      {
        m_currentSearchModel = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentSearchModel)));
      }
    }
    private ViewStateModel m_currentViewState;
    public ViewStateModel CurrentViewState
    {
      get => m_currentViewState;
      set
      {
        m_currentViewState = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentViewState)));
      }
    }
    public Command ToggleViewCommand
    {
      get
      {
        return new Command<string>((viewName) =>
        {
          CurrentViewState.View = viewName;
          CurrentViewState.IsScore = viewName == "Scores";
          CurrentViewState.IsPenalty = viewName == "Penalties";
        });
      }
    }
   

    private List<Models.SectionReview> m_baseSectionReviewList;
    private ObservableCollection<Models.SectionReview> m_SectionReview;
    public ObservableCollection<Models.SectionReview> SectionReviewCollection
    {
      get => m_SectionReview;
      set
      {
        m_SectionReview = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SectionReviewCollection)));
      }
    }

    private List<Models.EventCategoryPenalty> m_baseEventCategortPenaltyList;
    private ObservableCollection<Models.EventCategoryPenalty> m_penaltyReview;
    public ObservableCollection<Models.EventCategoryPenalty> PenaltyReviewCollection
    {
      get => m_penaltyReview;
      set
      {
        m_penaltyReview = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PenaltyReviewCollection)));
      }
    }

    private ObservableCollection<string> m_eventDates;
    public ObservableCollection<string> EventDates
    {
      get => m_eventDates;
      set
      {
        m_eventDates = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(EventDates)));
      }
    }


    private ObservableCollection<Section> m_sections;
    public ObservableCollection<Section> Sections
    {
      get => m_sections;
      set
      {
        m_sections = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Sections)));
      }
    }


    private ObservableCollection<Team> m_teams;
    public ObservableCollection<Team> Teams
    {
      get => m_teams;
      set
      {
        m_teams = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Teams)));
      }
    }


    private ObservableCollection<Judge> m_judges;
    public ObservableCollection<Judge> Judges
    {
      get => m_judges;
      set
      {
        m_judges = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Judges)));
      }
    }



    public Command ClearCommand
    {
      get
      {
        return new Command(() =>
        {
          IsBusy = true;
          // clear filter fields and reset display
          CurrentSearchModel = new SearchModel();
          SectionReviewCollection = new ObservableCollection<Models.SectionReview>(m_baseSectionReviewList.OrderBy(er => er.SortOrder));
          PenaltyReviewCollection = new ObservableCollection<Models.EventCategoryPenalty>(m_baseEventCategortPenaltyList.OrderBy(p => p.CreatedDateTime));
          IsBusy = false;
        });
      }
    }

    public Command FilterCommand
    {
      get
      {
        return new Command(() =>
        {
          IsBusy = true;
          // get filter values
          DateTime eventDate = DateTime.Parse(CurrentSearchModel.EventDate == null || CurrentSearchModel.EventDate == "(all)" ? "1/1/1900" : CurrentSearchModel.EventDate);
          int sectionId = CurrentSearchModel.Section == null ? 0 : CurrentSearchModel.Section.SectionID;
          string judgeId = CurrentSearchModel.Judge == null ? string.Empty : CurrentSearchModel.Judge.JudgeID;
          int teamId = CurrentSearchModel.Team == null ? 0 : CurrentSearchModel.Team.TeamID;

          // new sectionReview list to fill
          List<Models.SectionReview> filteredSectionReviewList =
            m_baseSectionReviewList.Where(s => s.Id == sectionId || sectionId == 0)
              .Select(s => new Models.SectionReview() { Id = s.Id, Name = s.Name, SortOrder = s.SortOrder,
                Teams = s.Teams.Where(t => (t.TeamID == teamId || teamId == 0) && (t.StartTime.Date == eventDate || eventDate.Equals(DateTime.Parse("1/1/1900"))))
                .Select(tm => new Models.EventTeam()
                {
                  Active = tm.Active,
                  CategoryID = tm.CategoryID,
                  CategoryName = tm.CategoryName,
                  Date = tm.Date,
                  DateTimeInOut = tm.DateTimeInOut,
                  Done = tm.Done,
                  Email = tm.Email,
                  EndTime = tm.EndTime,
                  EventID = tm.EventID,
                  Judges = tm.Judges == null ? null : tm.Judges.Where(j => j.Id == judgeId || string.IsNullOrEmpty(judgeId)).ToList(),
                  JudgeUserID = tm.JudgeUserID,
                  Members = tm.Members,
                  PenaltyCount = tm.PenaltyCount,
                  Phone = tm.Phone,
                  PrimaryContactName = tm.PrimaryContactName,
                  SchoolName = tm.SchoolName,
                  SortOrder = tm.SortOrder,
                  StartTime = tm.StartTime,
                  TeamID = tm.TeamID,
                  TeamName = tm.TeamName,
                  TimeIn = tm.TimeIn,
                  TimeOut = tm.TimeOut
                }).ToList()
               }).ToList();
          // replace observable collection
          SectionReviewCollection = new ObservableCollection<Models.SectionReview>(filteredSectionReviewList.OrderBy(er => er.SortOrder));

          // new penalty list to fill
          List<Models.EventCategoryPenalty> filteredPenaltyReviewList =
            m_baseEventCategortPenaltyList.Where(p =>
              (p.CreatedDateTime.Date == eventDate || eventDate.Equals(DateTime.Parse("1/1/1900"))) &&
              (p.SectionID == sectionId || sectionId == 0) &&
              (p.TeamID == teamId || teamId == 0) &&
              (p.JudgeUserID == judgeId || string.IsNullOrEmpty(judgeId)))
              .ToList();
          // replace observable collection
          PenaltyReviewCollection = new ObservableCollection<Models.EventCategoryPenalty>(filteredPenaltyReviewList.OrderBy(p => p.CreatedDateTime));

          IsBusy = false;
        });
      }
    }

    public ICommand TapJudgeScoreCommand
    {
      get
      {
        return new Command<Models.TeamJudge>(async (judgeUser) =>
        {
          IsBusy = true;
          //Application.Current.MainPage.DisplayAlert("Judge User", Newtonsoft.Json.JsonConvert.SerializeObject(judgeUser), "Close");
          // put everything in the model object
          var sectionTeamJudgeModel = new Models.SectionTeam()
          {
            CategoryID = CurrentEvent.CategoryID,
            CategoryName = CurrentEvent.CategoryName,
            EventID = CurrentEvent.EventID,
            EventName = CurrentEvent.EventName,
            SectionID = judgeUser.SectionID,
            SectionName = judgeUser.SectionName,
            TeamID = judgeUser.TeamID,
            TeamName = judgeUser.TeamNane,
            JudgeID = judgeUser.Id,
            JudgeName = judgeUser.JudgeName
          };
          // create new page and bind to viewmodel with above data
          var eventPage = new Views.SectionTeamJudgeDetail();
          var eventVM = new SectionTeamJudgeDetailVM(sectionTeamJudgeModel);
          eventPage.BindingContext = eventVM;
          // navigate to new page
          await Application.Current.MainPage.Navigation.PushAsync(eventPage);

          IsBusy = false;
        });
      }
    }

    public ICommand TapPenaltyApprove
    {
      get
      {
        return new Command<Models.EventCategoryPenalty>(async (penalty) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Approve Penalty", "This will approve the selected penalty and include it in the team's score. This operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            var teamSectionPenaltyStatus = new Models.TeamSectionPenaltyStatus() { ID = penalty.ID, PenaltyStatusID = Constants.PenaltyStatus.APPROVED };
            _apiServices.UpdateTeamSectionPenaltyStatus(teamSectionPenaltyStatus);
            penalty.PenaltyStatusID = Constants.PenaltyStatus.APPROVED; penalty.StatusName = "Approved";
            penalty.IsStatusPending = false; penalty.IsStatusResolved = true;
          }
          IsBusy = false;
        });
      }
    }

    public ICommand TapPenaltyDeny
    {
      get
      {
        return new Command<Models.EventCategoryPenalty>(async (penalty) =>
        {
          IsBusy = true;
          bool answer = await Application.Current.MainPage.DisplayAlert("Deny Penalty", "This will deny the selected penalty and it will not be counted in the the team's score. This operation cannot be undone.", "OK", "Cancel");
          if (answer)
          {
            var teamSectionPenaltyStatus = new Models.TeamSectionPenaltyStatus() { ID = penalty.ID, PenaltyStatusID = Constants.PenaltyStatus.DENIED };
            _apiServices.UpdateTeamSectionPenaltyStatus(teamSectionPenaltyStatus);
            penalty.PenaltyStatusID = Constants.PenaltyStatus.DENIED; penalty.StatusName = "Denied";
            penalty.IsStatusPending = false; penalty.IsStatusResolved = true;
          }
          IsBusy = false;
        });
      }
    }

    public EventReviewVM(Models.EventCategory MyEvent)
    {
      IsBusy = true;
      // initialize view
      CurrentEvent = MyEvent;
      CurrentSearchModel = new SearchModel();
      CurrentViewState = new ViewStateModel() { View = "Scores", IsScore = true, IsPenalty = false };

      // load data from server first time
      m_baseEventCategortPenaltyList = _apiServices.GetEventCategoryPenalties(CurrentEvent.EventID, CurrentEvent.CategoryID);
      PenaltyReviewCollection = new ObservableCollection<Models.EventCategoryPenalty>(m_baseEventCategortPenaltyList.OrderBy(p => p.CreatedDateTime));
      m_baseSectionReviewList = _apiServices.GetSectionReview(CurrentEvent.EventID, CurrentEvent.CategoryID);
      // fill in section and team for everyone
      foreach (Models.SectionReview section in m_baseSectionReviewList)
      {
        foreach (Models.EventTeam team in section.Teams)
        {
          foreach (Models.TeamJudge teamJudge in team.Judges)
          {
            teamJudge.SectionID = section.Id;
            teamJudge.SectionName = section.Name;
            teamJudge.TeamID = team.TeamID;
            teamJudge.TeamNane = team.TeamName;
          }
        }
      }
      SectionReviewCollection = new ObservableCollection<Models.SectionReview>(m_baseSectionReviewList.OrderBy(er => er.SortOrder));

      // setup data for picklists
      EventDates = new ObservableCollection<string>(m_baseSectionReviewList[0].Teams.Select(t => t.StartTime.ToString("D")).Distinct().ToList());
      Sections = new ObservableCollection<Section>(m_baseSectionReviewList
        .OrderBy(er => er.SortOrder)
        .Select(s => new Section() { SectionName = s.Name, SectionID = s.Id })
        .ToList());
      Teams = new ObservableCollection<Team>(m_baseSectionReviewList
        .SelectMany(s => s.Teams)
        .GroupBy(g => new { g.TeamID, g.TeamName })
        .Select(t => new Team() { TeamID = t.Key.TeamID, TeamName = t.Key.TeamName })
        .OrderBy(t => t.TeamName)
        .ToList());
      Judges = new ObservableCollection<Judge>(m_baseSectionReviewList
        .SelectMany(s => s.Teams)
        .SelectMany(t => t.Judges)
        .GroupBy(g => new { g.Id, JudgeName = g.FirstName.Trim() + " " + g.LastName.Trim() })
        .Select(j => new Judge() { JudgeID = j.Key.Id, JudgeName = j.Key.JudgeName })
        .OrderBy(j => j.JudgeName)
        .ToList());

      // items for selecting all
      EventDates.Insert(0, "(all)");
      Sections.Insert(0, new Section() { SectionID = 0, SectionName = "(all)" });
      Teams.Insert(0, new Team() { TeamID = 0, TeamName = "(all)" });
      Judges.Insert(0, new Judge() { JudgeID = string.Empty, JudgeName = "(all)" });

      IsBusy = false;
    }
  }

  public class Section
  {
    public int SectionID { get; set; }
    public string SectionName { get; set; }
  }
  public class Team
  {
    public int TeamID { get; set; }
    public string TeamName { get; set; }
  }
  public class Judge
  {
    public string JudgeID { get; set; }
    public string JudgeName { get; set; }
  }

  public class ViewStateModel : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    private string m_view;
    public string View
    {
      get => m_view;
      set 
      {
        m_view = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(View)));
      }
    }
    private bool m_score;
    public bool IsScore
    {
      get => m_score;
      set
      {
        m_score = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsScore)));
      }
    }
    private bool m_penalty;
    public bool IsPenalty
    {
      get => m_penalty;
      set
      {
        m_penalty = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsPenalty)));
      }
    }
  }

  public class SearchModel : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    private string m_eventDate;
    public string EventDate 
    {
      get => m_eventDate;
      set
      {
        m_eventDate = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(EventDate)));
      }
    }

    private Section m_section;
    public Section Section 
    {
      get => m_section;
      set 
      {
        m_section = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Section)));
      }
    }

    private Team m_team;
    public Team Team 
    {
      get => m_team;
      set
      {
        m_team = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Team)));
      }
    }

    private Judge m_judge;
    public Judge Judge 
    {
      get => m_judge;
      set 
      {
        m_judge = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Judge)));
      }
    }
  }
}
