﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

namespace NpsiJudgingApp.ViewModels
{
  public class PopupSubsectionCriteriaVM: INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    private ObservableCollection<Models.Criteria> m_criteria;
    public ObservableCollection<Models.Criteria> CriteriaList
    {
      get => m_criteria;
      set
      {
        m_criteria = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CriteriaList)));
      }
    }

    public PopupSubsectionCriteriaVM(List<Models.Criteria> MyCriteria)
    {
      CriteriaList = new ObservableCollection<Models.Criteria>(MyCriteria);
    }
  }
}
