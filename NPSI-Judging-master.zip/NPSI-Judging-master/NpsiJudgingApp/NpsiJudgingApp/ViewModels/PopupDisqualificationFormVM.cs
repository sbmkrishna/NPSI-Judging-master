﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using NpsiJudgingApp.Services;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;
using Rg.Plugins.Popup.Services;

namespace NpsiJudgingApp.ViewModels
{
  public class PopupDisqualificationFormVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    public delegate void DisqualificationUpdated(bool NeedRefresh);
    public event DisqualificationUpdated DisqualificationUpdatedEvent;

    private Models.TeamSectionDisqualification mo_teamSectionDisqualification;
    public Models.TeamSectionDisqualification CurrentTeamDisqualification
    {
      get => mo_teamSectionDisqualification;
      set 
      {
        mo_teamSectionDisqualification = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentTeamDisqualification)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsNew)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsExisting)));
      }
    }
    public bool IsNew { get => (CurrentTeamDisqualification.ID == 0); }
    public bool IsExisting { get => (CurrentTeamDisqualification.ID != 0); }


    private ObservableCollection<Models.Disqualification> mo_disqualificationList;
    public ObservableCollection<Models.Disqualification> DisqualificationList
    {
      get => mo_disqualificationList;
      set
      {
        mo_disqualificationList = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisqualificationList)));
      }
    }

    private Models.Disqualification mo_selectedDisqualification;
    public Models.Disqualification SelectedDisqualification
    {
      get => mo_selectedDisqualification;
      set
      {
        mo_selectedDisqualification = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedDisqualification)));
        CurrentTeamDisqualification.DisqualificationID = mo_selectedDisqualification.ID.Value;
        CurrentTeamDisqualification.Name = mo_selectedDisqualification.Name;
      }
    }

    public ICommand SaveDisqualification
    {
      get
      {
        return new Command(async () =>
        {
          try
          {
            if (string.IsNullOrEmpty(CurrentTeamDisqualification.Comments)) throw new Exception("Comments are required for every disqualification.");

            if (CurrentTeamDisqualification.ID == 0)
              _apiServices.InsertTeamSectionDisqualification(CurrentTeamDisqualification);
            else
              _apiServices.UpdateTeamSectionDisqualification(CurrentTeamDisqualification);
            DisqualificationUpdatedEvent?.Invoke(true);
            await PopupNavigation.Instance.PopAsync();
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
          //Application.Current.MainPage.DisplayAlert("Testing", Newtonsoft.Json.JsonConvert.SerializeObject(CurrentTeamPenalty), "Cancel");
        });
      }
    }

    public ICommand CancelDisqualification
    {
      get
      {
        return new Command(async () =>
        {
          DisqualificationUpdatedEvent?.Invoke(false);
          await PopupNavigation.Instance.PopAsync();
        });
      }
    }

    public PopupDisqualificationFormVM(Models.TeamSectionDisqualification MyTeamSectionDisqualification)
    {
      CurrentTeamDisqualification = MyTeamSectionDisqualification;
      DisqualificationList = new ObservableCollection<Models.Disqualification>(_apiServices.GetEventSectionDisqualification(CurrentTeamDisqualification.EventID, CurrentTeamDisqualification.SectionID, CurrentTeamDisqualification.TeamID));
    }
  }
}
