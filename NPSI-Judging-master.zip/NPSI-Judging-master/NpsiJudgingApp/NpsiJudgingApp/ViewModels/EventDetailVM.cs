﻿using System.Windows.Input;
using Xamarin.Forms;
using NpsiJudgingApp.Helpers;
using NpsiJudgingApp.Services;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;
using System.Linq;
using Rg.Plugins.Popup.Services;

namespace NpsiJudgingApp.ViewModels
{
  public class EventDetailVM : INotifyPropertyChanged
  {
    private readonly ApiServices _apiServices = new ApiServices();
    public event PropertyChangedEventHandler PropertyChanged;

    private bool m_isBusy;
    public bool IsBusy
    {
      get => m_isBusy;
      set
      {
        m_isBusy = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsBusy)));
      }
    }


    private List<Models.SectionJudging> m_baseSectionJudgingList;
    private ObservableCollection<Models.SectionJudging> m_SectionJudging;
    public ObservableCollection<Models.SectionJudging> Sections
    {
      get => m_SectionJudging;
      set
      {
        m_SectionJudging = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Sections)));
      }
    }


    public ObservableCollection<string> EventDates { get; set; }

    private Models.EventCategory m_currentEvent;
    public Models.EventCategory CurrentEvent
    {
      get => m_currentEvent;
      set
      {
        m_currentEvent = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentEvent)));
      }
    }

    private string m_selectedEventDate;
    public string SelectedEventDate
    {
      get => m_selectedEventDate;
      set 
      {
        m_selectedEventDate = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedEventDate)));
        RefreshSectionCollection();
      }
    }

    public Command SubmitSectionScores
    {
      get
      {
        return new Command<Models.SectionJudging>(async (sectionJudging) =>
        {
          IsBusy = true;
          try
          {
            bool answer = await Application.Current.MainPage.DisplayAlert("Submit Scores", "This will submit all your scores for review. The operation cannot be undone.", "OK", "Cancel");
            if (answer)
            {
              _apiServices.SubmitScores(CurrentEvent.EventID, sectionJudging.ID, sectionJudging.CategoryID);
              m_baseSectionJudgingList = _apiServices.GetEventCategorySections(CurrentEvent.EventID, CurrentEvent.CategoryID);
              RefreshSectionCollection();
            }
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Server Error", ex.Message, "OK");
          }
          finally
          {
            IsBusy = false;
          }
        });
      }
    }

    public ICommand ViewImage
    {
      get
      {
        return new Command<byte[]>(async (eventPhoto) =>
        {
          try
          {
            // make sure there's a valid image
            if (eventPhoto == null) throw new Exception("There is a problem with this image file.");
            // navigate to new page
            var popup = new Views.PopupImage(eventPhoto);
            popup.CloseWhenBackgroundIsClicked = true;
            await PopupNavigation.Instance.PushAsync(popup);
          }
          catch (Exception ex)
          {
            await Application.Current.MainPage.DisplayAlert("Error", ex.Message, "OK");
          }
        });
      }
    }

    public Command OpenScoringForm
    {
      get
      {
        return new Command<Models.EventTeam>(async (eventTeam) =>
        {
          IsBusy = true;
          var eventSectionTeam = new Models.EventSectionTeam()
          {
            EventID = CurrentEvent.EventID,
            EventName = CurrentEvent.EventName,
            SectionID = eventTeam.SubsectionScore.FirstOrDefault().SectionID,
            SectionName = Sections.FirstOrDefault(s => s.ID == eventTeam.SubsectionScore.FirstOrDefault().SectionID).Name,
            TeamID = eventTeam.TeamID,
            TeamName = eventTeam.TeamName,
            CategoryID = CurrentEvent.CategoryID,
            CategoryName = CurrentEvent.CategoryName
          };
          // create new page and bind to viewmodel with supplied data
          var eventPage = new Views.TeamSectionForm();
          var eventVM = new TeamSectionFormVM(eventSectionTeam);
          eventPage.ScoresUpdatedEvent += (info) =>
          {
            m_baseSectionJudgingList = _apiServices.GetEventCategorySections(CurrentEvent.EventID, CurrentEvent.CategoryID);
            RefreshSectionCollection();
            IsBusy = false;
          };
          eventPage.BindingContext = eventVM;
          // navigate to new page
          await Application.Current.MainPage.Navigation.PushAsync(eventPage);
        });
      }
    }

    private void RefreshSectionCollection()
    {
      DateTime eventDate = DateTime.Parse(string.IsNullOrEmpty(SelectedEventDate) ? "1/1/1900" : SelectedEventDate);

      List<Models.SectionJudging> listCopy = new List<Models.SectionJudging>();
      foreach (Models.SectionJudging sj in m_baseSectionJudgingList)
      {
        Models.SectionJudging sectionJudging = new Models.SectionJudging()
        {
          Active = sj.Active,
          CategoryID = sj.CategoryID,
          CategoryName = sj.CategoryName,
          DateTimeInOut = sj.DateTimeInOut,
          Description = sj.Description,
          EndTime = sj.EndTime,
          ID = sj.ID,
          Name = sj.Name,
          SortOrder = sj.SortOrder,
          StartTime = sj.StartTime,
          SubmittedDateTime = sj.SubmittedDateTime,
          TimeIn = sj.TimeIn,
          TimeInOutNeeded = sj.TimeInOutNeeded,
          TimeOut = sj.TimeOut,
          Teams = sj.Teams.Where(t => t.StartTime.Date == eventDate || string.IsNullOrEmpty(SelectedEventDate))
            .Select(tm => new Models.EventTeam()
            {
              Active = tm.Active,
              CategoryID = tm.CategoryID,
              CategoryName = tm.CategoryName,
              Date = tm.Date,
              DateTimeInOut = tm.DateTimeInOut,
              Done = tm.Done,
              Email = tm.Email,
              EndTime = tm.EndTime,
              EventID = tm.EventID,
              Judges = tm.Judges,
              JudgeUserID = tm.JudgeUserID,
              Members = tm.Members,
              PenaltyCount = tm.PenaltyCount,
              Phone = tm.Phone,
              PrimaryContactName = tm.PrimaryContactName,
              SchoolName = tm.SchoolName,
              SortOrder = tm.SortOrder,
              StartTime = tm.StartTime,
              TeamID = tm.TeamID,
              TeamName = tm.TeamName,
              TimeIn = tm.TimeIn,
              TimeOut = tm.TimeOut,
              Comments = tm.Comments,
              SubsectionScore = tm.SubsectionScore.Select(ss => new Models.Subsection()
              {
                CategoryID = ss.CategoryID,
                Comments = ss.Comments,
                Criteria = ss.Criteria,
                Description = ss.Description,
                EventID = ss.EventID,
                Excellent = ss.Excellent,
                Fair = ss.Fair,
                Good = ss.Good,
                Image = ss.Image,
                JudgeUserID = ss.JudgeUserID,
                MaxScore = ss.MaxScore,
                MinScore = ss.MinScore,
                Photo = ss.Photo,
                Poor = ss.Poor,
                ScoreConcept = ss.ScoreConcept,
                SectionID = ss.SectionID,
                SortIndex = ss.SortIndex,
                SubSectionID = ss.SubSectionID,
                SubSectionName = ss.SubSectionName,
                TeamID = ss.TeamID,
                VeryGood = ss.VeryGood,
                Score = (ss.Score == null ? null : new Models.ScoreModel()
                {
                  CreatedDateTime = ss.Score.CreatedDateTime,
                  Comments = ss.Score.Comments,
                  EventID = ss.Score.EventID,
                  ID = ss.Score.ID,
                  JudgeUserID = ss.Score.JudgeUserID,
                  Photo = ss.Score.Photo,
                  Score = ss.Score.Score,
                  SectionID = ss.Score.SectionID,
                  SubsectionID = ss.Score.SubsectionID,
                  TeamID = ss.Score.TeamID
                })
              }).OrderBy(ss => ss.SortIndex).ToList()
            }).OrderBy(t => t.StartTime).ThenBy(s => s.SortOrder).ToList()
        };

        listCopy.Add(sectionJudging);
      }

      Sections = new ObservableCollection<Models.SectionJudging>(listCopy);
    }

    public EventDetailVM(Models.EventCategory MyEvent)
    {
      CurrentEvent = MyEvent;

      m_baseSectionJudgingList = _apiServices.GetEventCategorySections(CurrentEvent.EventID, CurrentEvent.CategoryID);
      if (m_baseSectionJudgingList.Count == 0) throw new Exception("Your account has not been properly configured for this event.");
      EventDates = new ObservableCollection<string>(m_baseSectionJudgingList[0].Teams.Select(t => t.StartTime.ToString("D")).Distinct().ToList());

      RefreshSectionCollection();
    } 
  }
}
